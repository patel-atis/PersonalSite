$(document).ready(function(){
    $(".burger-nav").on("click", function(){
        $("nav ul").toggleClass("open"));
    });
});
